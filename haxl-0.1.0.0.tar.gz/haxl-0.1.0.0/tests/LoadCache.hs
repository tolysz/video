{-# LANGUAGE CPP, OverloadedStrings #-}
module LoadCache where

import Haxl.Core
import ExampleDataSource

#include "LoadCache.txt"
